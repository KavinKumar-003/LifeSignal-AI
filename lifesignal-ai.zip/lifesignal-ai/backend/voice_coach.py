from gtts import gTTS
import os


class VoiceCoach:
    """
    Generates spoken audio for the on-screen guidance text using gTTS.
    Note: gTTS calls Google's public text-to-speech endpoint, so this
    requires an active internet connection on the machine running the app.
    """

    @staticmethod
    def generate_instruction_audio(text, lang="en"):
        os.makedirs("data", exist_ok=True)
        audio_file = "data/emergency_coach.mp3"
        try:
            tts = gTTS(text=text, lang=lang, slow=False)
            tts.save(audio_file)
            return audio_file
        except Exception as e:
            print(f"Error generating audio: {e}")
            return None
