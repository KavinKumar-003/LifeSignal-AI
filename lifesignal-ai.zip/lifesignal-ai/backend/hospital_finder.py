import math
import requests

OVERPASS_URL = "https://overpass-api.de/api/interpreter"


def _haversine_km(lat1, lon1, lat2, lon2):
    R = 6371.0
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dphi = math.radians(lat2 - lat1)
    dlambda = math.radians(lon2 - lon1)
    a = math.sin(dphi / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dlambda / 2) ** 2
    return 2 * R * math.asin(math.sqrt(a))


class HospitalFinder:
    """
    Looks up real hospitals near a given lat/lon using OpenStreetMap's
    Overpass API (free, no API key required). Requires internet access
    on the machine running the app.
    """

    @staticmethod
    def find_nearby(lat, lon, radius_m=6000, limit=6):
        query = f"""
        [out:json][timeout:25];
        (
          node["amenity"="hospital"](around:{radius_m},{lat},{lon});
          way["amenity"="hospital"](around:{radius_m},{lat},{lon});
        );
        out center tags;
        """
        try:
            resp = requests.post(OVERPASS_URL, data={"data": query}, timeout=25)
            resp.raise_for_status()
            data = resp.json()
        except Exception as e:
            return {"error": str(e)}

        hospitals = []
        for el in data.get("elements", []):
            tags = el.get("tags", {})
            name = tags.get("name", "Unnamed hospital")

            if el["type"] == "node":
                h_lat, h_lon = el.get("lat"), el.get("lon")
            else:
                center = el.get("center", {})
                h_lat, h_lon = center.get("lat"), center.get("lon")

            if h_lat is None or h_lon is None:
                continue

            phone = tags.get("phone") or tags.get("contact:phone")
            hospitals.append({
                "name": name,
                "lat": h_lat,
                "lon": h_lon,
                "distance_km": round(_haversine_km(lat, lon, h_lat, h_lon), 2),
                "phone": phone,
                "maps_url": f"https://www.google.com/maps?q={h_lat},{h_lon}",
            })

        hospitals.sort(key=lambda h: h["distance_km"])
        return {"hospitals": hospitals[:limit]}
