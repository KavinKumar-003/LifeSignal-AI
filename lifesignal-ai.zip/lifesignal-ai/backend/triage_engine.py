import cv2
import numpy as np


class TriageEngine:
    """
    PROTOTYPE / DEMO ONLY.

    Uses a simple color-based heuristic (ratio of red-toned pixels in an
    image) as a rough, illustrative "visual indicator" — this is NOT a
    validated or clinically meaningful method for detecting injury or
    bleeding. Red pixels can come from clothing, lighting, vehicles, etc.

    Do not use this to make real first-aid or triage decisions. Always
    call your local emergency number in an actual emergency.
    """

    @staticmethod
    def analyze_scene(image_bytes):
        nparr = np.frombuffer(image_bytes, np.uint8)
        img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)

        if img is None:
            return None

        hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)

        # Red hue wraps around 0/180 in OpenCV's HSV, so two ranges are needed
        lower_red1 = np.array([0, 70, 50])
        upper_red1 = np.array([10, 255, 255])
        lower_red2 = np.array([170, 70, 50])
        upper_red2 = np.array([180, 255, 255])

        mask1 = cv2.inRange(hsv, lower_red1, upper_red1)
        mask2 = cv2.inRange(hsv, lower_red2, upper_red2)
        red_mask = mask1 | mask2

        red_pixels = cv2.countNonZero(red_mask)
        total_pixels = img.shape[0] * img.shape[1]
        red_ratio = (red_pixels / total_pixels) * 100

        possible_bleeding = red_ratio > 1.2

        if possible_bleeding:
            level = "HIGH VISUAL INDICATOR"
            color = "red"
            note = (
                "A higher-than-usual proportion of red tones was detected in the "
                "image. This MAY indicate visible bleeding, but could also be "
                "clothing, vehicle paint, or lighting — it is not a diagnosis."
            )
        else:
            level = "LOW VISUAL INDICATOR"
            color = "orange"
            note = "A lower proportion of red tones was detected in the image."

        # Intentionally generic — a color heuristic should never drive
        # specific clinical instructions (e.g. airway positioning), since
        # the wrong instruction for a suspected spinal/neck injury can
        # cause real harm.
        guidance_en = (
            "This is general public safety information, not a medical diagnosis. "
            "Call your local emergency number immediately. Do not move an injured "
            "person unless they are in immediate danger. Keep the person still, "
            "calm, and warm until trained help arrives."
        )
        guidance_hi = (
            "यह सामान्य सुरक्षा जानकारी है, चिकित्सीय निदान नहीं। तुरंत अपनी स्थानीय "
            "आपातकालीन सेवा को कॉल करें। घायल व्यक्ति को तब तक न हिलाएं जब तक वह "
            "तत्काल खतरे में न हो।"
        )
        guidance_ta = (
            "இது பொது பாதுகாப்பு தகவல் மட்டுமே, மருத்துவ ஆலோசனை அல்ல. உடனடியாக "
            "உங்கள் உள்ளூர் அவசர சேவையை அழைக்கவும். ஆபத்து இல்லாவிட்டால் காயமடைந்தவரை "
            "நகர்த்த வேண்டாம்."
        )

        # Standard, widely-published first-aid precautions for visible
        # bleeding (e.g. Red Cross / WHO general public guidance). These are
        # only shown as *general* precautions alongside the call-for-help
        # instruction above — never as a stand-in for professional care.
        bleeding_precautions_en = [
            "Call your local emergency number immediately — do this first.",
            "If you have gloves, put them on before touching the wound.",
            "Apply firm, steady, direct pressure on the wound with a clean cloth or dressing.",
            "Do not remove the cloth if it soaks through — add more layers on top instead.",
            "Do not remove any object embedded in the wound — pad around it and press near it, not on it.",
            "If safe and no spinal injury is suspected, keep the injured area raised above the level of the heart.",
            "Keep the person lying down, still, and warm to help prevent shock.",
            "Do not give the person food or water.",
            "Keep maintaining pressure until emergency responders take over.",
        ]
        bleeding_precautions_hi = [
            "सबसे पहले तुरंत अपनी स्थानीय आपातकालीन सेवा को कॉल करें।",
            "यदि उपलब्ध हो तो घाव को छूने से पहले दस्ताने पहनें।",
            "साफ कपड़े या पट्टी से घाव पर सीधा और मजबूत दबाव बनाए रखें।",
            "यदि कपड़ा खून से भीग जाए तो उसे न हटाएं, ऊपर से और परतें लगाएं।",
            "घाव में फंसी किसी वस्तु को न निकालें।",
            "व्यक्ति को लिटाकर रखें, हिलने न दें और गर्म रखें।",
            "मदद पहुंचने तक दबाव बनाए रखें।",
        ]
        bleeding_precautions_ta = [
            "முதலில் உடனடியாக உங்கள் உள்ளூர் அவசர சேவையை அழைக்கவும்.",
            "கையுறை இருந்தால் காயத்தைத் தொடும் முன் அணியவும்.",
            "சுத்தமான துணியால் காயத்தின் மீது நேரடியாக உறுதியான அழுத்தம் கொடுக்கவும்.",
            "துணி நனைந்தால் அதை எடுக்காமல் மேலும் அடுக்குகளைச் சேர்க்கவும்.",
            "காயத்தில் ஏதேனும் பொருள் சிக்கியிருந்தால் அதை எடுக்க வேண்டாம்.",
            "பாதிக்கப்பட்டவரை அசைக்காமல், படுக்க வைத்து, சூடாக வைத்திருக்கவும்.",
            "உதவி வரும் வரை அழுத்தத்தைத் தொடரவும்.",
        ]

        return {
            "level": level,
            "color": color,
            "note": note,
            "red_ratio": round(red_ratio, 2),
            "possible_bleeding": possible_bleeding,
            "guidance_en": guidance_en,
            "guidance_hi": guidance_hi,
            "guidance_ta": guidance_ta,
            "bleeding_precautions_en": bleeding_precautions_en,
            "bleeding_precautions_hi": bleeding_precautions_hi,
            "bleeding_precautions_ta": bleeding_precautions_ta,
        }
