import streamlit as st
import sys
import os
from PIL import Image

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from backend.triage_engine import TriageEngine
from backend.voice_coach import VoiceCoach
from backend.hospital_finder import HospitalFinder

try:
    from streamlit_js_eval import get_geolocation
    HAS_GEOLOCATION = True
except ImportError:
    HAS_GEOLOCATION = False

st.set_page_config(page_title="LifeSignal AI (Prototype)", layout="wide", page_icon="🚨")

st.title("🚨 LifeSignal AI — Prototype")
st.caption("Illustrative computer-vision indicator + real nearby-hospital finder")

st.warning(
    "⚠️ **This is a non-functional prototype.** It does NOT call, alert, or "
    "dispatch any real ambulance, hospital, or emergency service. The "
    "\"visual indicator\" is a simple color heuristic, not a medical "
    "diagnosis. **In a real emergency, call your local emergency number "
    "immediately.**"
)
st.markdown("---")

col1, col2 = st.columns([1, 2])

with col1:
    st.subheader("📹 Scene Image")
    uploaded_img = st.file_uploader("Upload an image / frame", type=["jpg", "png", "jpeg"])
    demo_btn = st.button("▶️ Load Demo Scene")

    lang = st.selectbox("Guidance language", ["English", "Hindi (हिंदी)", "Tamil (தமிழ்)"])

with col2:
    st.subheader("📊 Visual Indicator & General Safety Guidance")

    image_bytes = None
    if uploaded_img:
        image_bytes = uploaded_img.getvalue()
        st.image(Image.open(uploaded_img), caption="Uploaded scene", width=400)
    elif demo_btn:
        st.info("Demo scene loaded (synthetic example, no real image analyzed).")
        image_bytes = b"demo"

    if image_bytes:
        if image_bytes == b"demo":
            triage_res = {
                "level": "HIGH VISUAL INDICATOR",
                "color": "red",
                "note": "Synthetic demo value for illustration purposes only.",
                "red_ratio": 3.4,
                "possible_bleeding": True,
                "guidance_en": (
                    "This is general public safety information, not a medical diagnosis. "
                    "Call your local emergency number immediately. Do not move an injured "
                    "person unless they are in immediate danger. Keep the person still, "
                    "calm, and warm until trained help arrives."
                ),
                "guidance_hi": (
                    "यह सामान्य सुरक्षा जानकारी है, चिकित्सीय निदान नहीं। तुरंत अपनी स्थानीय "
                    "आपातकालीन सेवा को कॉल करें।"
                ),
                "guidance_ta": (
                    "இது பொது பாதுகாப்பு தகவல் மட்டுமே, மருத்துவ ஆலோசனை அல்ல. உடனடியாக "
                    "உங்கள் உள்ளூர் அவசர சேவையை அழைக்கவும்."
                ),
                "bleeding_precautions_en": [
                    "Call your local emergency number immediately — do this first.",
                    "If you have gloves, put them on before touching the wound.",
                    "Apply firm, steady, direct pressure on the wound with a clean cloth or dressing.",
                    "Do not remove the cloth if it soaks through — add more layers on top instead.",
                    "Do not remove any object embedded in the wound.",
                    "Keep the person lying down, still, and warm to help prevent shock.",
                    "Do not give the person food or water.",
                    "Keep maintaining pressure until emergency responders take over.",
                ],
                "bleeding_precautions_hi": [
                    "सबसे पहले तुरंत अपनी स्थानीय आपातकालीन सेवा को कॉल करें।",
                    "साफ कपड़े से घाव पर सीधा और मजबूत दबाव बनाए रखें।",
                    "व्यक्ति को लिटाकर रखें, हिलने न दें और गर्म रखें।",
                ],
                "bleeding_precautions_ta": [
                    "முதலில் உடனடியாக உங்கள் உள்ளூர் அவசர சேவையை அழைக்கவும்.",
                    "சுத்தமான துணியால் காயத்தின் மீது நேரடியாக உறுதியான அழுத்தம் கொடுக்கவும்.",
                    "பாதிக்கப்பட்டவரை அசைக்காமல், படுக்க வைத்து, சூடாக வைத்திருக்கவும்.",
                ],
            }
        else:
            triage_res = TriageEngine.analyze_scene(image_bytes)

        if triage_res:
            if triage_res["color"] == "red":
                st.error(f"Visual indicator: {triage_res['level']} (demo heuristic, not diagnostic)")
            else:
                st.warning(f"Visual indicator: {triage_res['level']} (demo heuristic, not diagnostic)")

            st.markdown(f"**Note:** {triage_res['note']}  \n**Red pixel ratio:** {triage_res['red_ratio']}%")

            if "Hindi" in lang:
                guidance_text = triage_res['guidance_hi']
                lang_code = "hi"
            elif "Tamil" in lang:
                guidance_text = triage_res['guidance_ta']
                lang_code = "ta"
            else:
                guidance_text = triage_res['guidance_en']
                lang_code = "en"

            with st.container(border=True):
                st.subheader("🗣️ General Safety Guidance")
                st.write(guidance_text)

                audio_file = VoiceCoach.generate_instruction_audio(guidance_text, lang=lang_code)
                if audio_file and os.path.exists(audio_file):
                    st.audio(audio_file, format="audio/mp3")
                else:
                    st.info("Audio generation needs an internet connection (gTTS calls Google's TTS service).")

            if triage_res.get("possible_bleeding"):
                precautions_key = {
                    "hi": "bleeding_precautions_hi",
                    "ta": "bleeding_precautions_ta",
                }.get(lang_code, "bleeding_precautions_en")
                precautions = triage_res.get(precautions_key, [])

                with st.container(border=True):
                    st.subheader("🩹 Possible Bleeding — General Precautions")
                    st.caption(
                        "Shown because the visual indicator was elevated — this is not "
                        "confirmed bleeding. These are standard general-public first-aid "
                        "precautions, not a substitute for emergency responders."
                    )
                    for step in precautions:
                        st.markdown(f"- {step}")

st.markdown("---")
st.subheader("🏥 Find Nearby Hospitals & Get Help")
st.caption(
    "This looks up real hospitals near a location using OpenStreetMap data. "
    "It does not notify anyone automatically — use the call/share links to act."
)

detected_lat, detected_lon = None, None
if HAS_GEOLOCATION:
    loc = get_geolocation()
    if loc and "coords" in loc:
        detected_lat = loc["coords"]["latitude"]
        detected_lon = loc["coords"]["longitude"]
        st.success(f"Location detected: {detected_lat:.5f}, {detected_lon:.5f}")
else:
    st.info("Install `streamlit-js-eval` for one-click browser location, or enter coordinates manually below.")

col_lat, col_lon = st.columns(2)
with col_lat:
    lat_input = st.number_input("Latitude", value=detected_lat if detected_lat else 12.9716, format="%.6f")
with col_lon:
    lon_input = st.number_input("Longitude", value=detected_lon if detected_lon else 77.5946, format="%.6f")

find_btn = st.button("🔍 Find Nearby Hospitals")

if find_btn:
    with st.spinner("Searching nearby hospitals..."):
        result = HospitalFinder.find_nearby(lat_input, lon_input)

    if "error" in result:
        st.error(f"Couldn't reach the hospital lookup service: {result['error']}")
    elif not result["hospitals"]:
        st.warning("No hospitals found nearby in OpenStreetMap data. Try widening the search or calling emergency services directly.")
    else:
        maps_link = f"https://www.google.com/maps?q={lat_input},{lon_input}"
        st.markdown(f"📍 [View this location on Google Maps]({maps_link})")

        for h in result["hospitals"]:
            with st.container(border=True):
                st.markdown(f"**{h['name']}** — {h['distance_km']} km away")
                c1, c2, c3 = st.columns(3)
                with c1:
                    st.markdown(f"[📍 Directions]({h['maps_url']})")
                with c2:
                    if h["phone"]:
                        st.markdown(f"[📞 Call]({'tel:' + h['phone']})")
                    else:
                        st.caption("No phone listed")
                with c3:
                    share_text = f"Need help near {lat_input},{lon_input}. Nearest hospital: {h['name']} ({h['maps_url']})"
                    wa_link = f"https://wa.me/?text={share_text.replace(' ', '%20')}"
                    st.markdown(f"[💬 Share via WhatsApp]({wa_link})")

        st.markdown("---")
        st.markdown(f"🚑 **In an emergency, call your local emergency number directly:** [📞 Call 108 (India)](tel:108)")
